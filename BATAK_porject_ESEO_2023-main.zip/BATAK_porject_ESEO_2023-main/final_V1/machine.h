/*
 * machine.h
 *
 *  Created on: 9 janv. 2024
 *      Author: alexi
 */

#ifndef MACHINE_H_
#define MACHINE_H_

void debutJeu();
void affichedebut();
void jeu();
void vide();
void fin();

#endif /* MACHINE_H_ */
