/*
 * Aff_4_7_Segg.h
 *
 *  Created on: 16 nov. 2023
 *      Author: alexi
 */

#ifndef AFF_4_7_SEGG_H_
#define AFF_4_7_SEGG_H_

void Afficher();

#endif /* AFF_4_7_SEGG_H_ */
