/*
 * PWM_Bargraphe.h
 *
 *  Created on: 1 d�c. 2023
 *      Author: alexi
 *  Connexion to A9
 */

#ifndef PWM_BARGRAPHE_H_
#define PWM_BARGRAPHE_H_

void testbar();
void process_ms(void);



#endif /* PWM_BARGRAPHE_H_ */
