Projet_BATAK_ESEO_2023

* Il s'agit d'un projet étudiant d'une durée de 5 mois.
* Nous utilisons un STM32F103.
* Notre objectif est de créer un BATAK (test de réflexes utilisé notamment par les pilotes et les gardiens de but).
* Merci de ne pas utiliser ce code pour vos propres projets.

* This is a student project lasting for at least 5 months.
* We use an STM32F103.
* Our goal is to create a BATAK (reflex test machine used by drivers and goalkeepers, for example).
* Do not use this code for your projects, thanks.

Terminé !
Finish !

* Nous avons créé un BATAK.
* Cependant, un problème persiste avec le bargraphe : le driver doit être remplacé par un registre à décalage.
* Voici le lien pour la vidéo en français: https://www.youtube.com/watch?v=2RmNbjxtR2U

* We have created the BATAK.
* However, there is an issue with the bargraph; the current driver needs to be replaced by a shift register.
